package com.techwerx.labelprocessing.prestige.initialise;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.sun.jna.Platform;
import com.techwerx.image.utils.SysOutController;
import com.techwerx.labelprocessing.prestige.CheckProductProperties;
import com.techwerx.labelprocessing.prestige.ProductPriceData;

public class InitialiseParameters {

	static {
		System.setProperty("jna.debug_load", "true");
	}

	// private static final InitialiseParameters instance = new
	// InitialiseParameters();

	// public static String initialisationFile =
	// "D:\\130052-TTK_VISION\\VISION\\ReadLabelsConfig.properties.ini";

	private static String initialisationFile = "E:/TechWerx/Java/Working/Input/Initialisation Properties/config.properties";
	private static String productSettingsFile = "E:/TechWerx/Java/Working/Input/Initialisation Properties/product.properties";
	private static String externalLibFolderKey = "externallib.folder";
	private static final String inputFolderKey = "input.folder";
	private static long productPropertiesTimestamp = 0L;

	private InitialiseParameters() {
	}

	public static boolean initialise() {

		java.util.Properties props = new java.util.Properties();
		// InputStream inputStream =
		// instance.getClass().getClassLoader().getResourceAsStream(initialisationFile);
		File initFile = new File(initialisationFile);
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(initFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (inputStream != null) {
			try {
				props.load(inputStream);
			} catch (Exception e) {
				System.out.println("Property initialisation file " + initialisationFile + " not found in the classpath "
						+ System.getProperty("java.class.path"));
				e.printStackTrace();
				return false;
			}
		} else {
			System.out.println("InputStream = null");
			System.out.println("Property initialisation file " + initialisationFile + " not found in the classpath "
					+ System.getProperty("java.class.path"));
			return false;
		}
		boolean isWindows = Platform.isWindows();
		String extension = isWindows ? ".dll" : ".so";
		String tesseractLib = System.getProperty("tesseractLib");
		String leptLib = System.getProperty("leptLib");

		Set<Map.Entry<Object, Object>> entries = props.entrySet();
		boolean externalLibFolderFound = false;
		String externalLibFolder = null;
		for (Map.Entry<Object, Object> entry : entries) {
			System.setProperty(entry.getKey().toString(), entry.getValue().toString());
			if (externalLibFolderKey.equals(entry.getKey().toString())) {
				externalLibFolderFound = true;
				externalLibFolder = entry.getValue().toString();
				externalLibFolder = new File(externalLibFolder).getAbsolutePath();
				// System.setProperty("java.io.tmpdir", entry.getValue().toString());
				// String jnaPath = props.getProperty("jna.library.path");
				// if ((jnaPath == null) || (jnaPath.indexOf("tess") == -1)) {
				// System.setProperty("jna.library.path", entry.getValue().toString() +
				// "/tess4j");
				// }
				// System.setProperty("jna.library.path", "");
				// String libraryPath = props.getProperty("java.library.path");
				// if ((libraryPath == null) || (libraryPath.indexOf("tess") == -1)) {
				// System.setProperty("java.library.path",
				// new StringBuffer().append(libraryPath == null ? "" : libraryPath)
				// .append(";" + entry.getValue().toString() + "/tess4j").toString());
				// }

				// concatenate the existing externallib folder to the PATH (Windows) /
				// LD_LIBRARY_PATH (Unix)
				String libPath = System.getProperty("java.library.path");
				String newPath;
				if ((libPath == null) || libPath.isEmpty()) {
					newPath = externalLibFolder;
				} else {
					newPath = externalLibFolder + File.pathSeparator + libPath;
				}
				System.setProperty("java.library.path", newPath);
			}
			if ("tesseract.datapath".equals(entry.getKey().toString())) {
				System.setProperty("TESSDATA_PREFIX", entry.getValue().toString());
			}
		}
		if (!externalLibFolderFound) {
			// the temp dir is where a folder is made and the native library is copied by
			// java for loading
			System.setProperty("java.io.tmpdir", System.getProperty(inputFolderKey) + "/External Libraries");
			System.setProperty("java.library.path", System.getProperty(inputFolderKey) + "/External Libraries");
		}
		// when Native.loadLibrary or System.loadLibrary is called, it resets the
		// library path.
		// The following is an attempt to subvert that by adding it to the sys_paths
		// variable which is what is called by the loadLibrary() methods to iterate
		// through the library paths, jars, wars, etc to find the native library
		try {
			Field field = ClassLoader.class.getDeclaredField("sys_paths");
			field.setAccessible(true);

			// Create override for sys_paths
			ClassLoader classLoader = ClassLoader.getSystemClassLoader();
			List<String> newSysPaths = new ArrayList<>();
			newSysPaths.add(externalLibFolder);
			newSysPaths.addAll(Arrays.asList((String[]) field.get(classLoader)));
			field.set(classLoader, newSysPaths.toArray(new String[newSysPaths.size()]));
		} catch (Exception e) {

		}

		try {
			// System.out.println("java.library.path = " +
			// System.getProperty("java.library.path"));
			// System.out.println("leptLib = " + leptLib);
			// System.loadLibrary(leptLib);
			String library = externalLibFolder + File.separator + leptLib + extension;
			// System.out.println("Trying to load : " + library);
			System.load(library); // using this as it takes the full path, unlike all the other methods
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Could not load library " + leptLib);
		}
		try {
			// System.out.println("java.library.path = " +
			// System.getProperty("java.library.path"));
			// System.out.println("tesseractLib = " + tesseractLib);
			// System.loadLibrary(tesseractLib);
			String library = externalLibFolder + File.separator + tesseractLib + extension;
			// System.out.println("Trying to load : " + library);
			System.load(library); // using this as it takes the full path, unlike all the other methods
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Could not load library " + tesseractLib);
		}

		// System.out.println("System Properties = " + System.getProperties());
		// solves the problem of "IllegalArgumentException" with Comparator.sort
		// System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
		System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
		// System.out.println("Temp folder = " + System.getProperty("java.io.tmpdir"));
		// System.out.println("Library path = " +
		// System.getProperty("jna.library.path"));
		return true;
	}

	public static boolean initialise(String file, boolean useFallbackInitialisationOption) {

		java.util.Properties props = new java.util.Properties();
		// InputStream inputStream =
		// instance.getClass().getClassLoader().getResourceAsStream(initialisationFile);
		File initFile = null;
		if ((file != null) && !("".equals(file))) {
			initFile = new File(file);
		} else {
			if (useFallbackInitialisationOption) {
				initFile = new File(initialisationFile);
			} else {
				SysOutController.resetSysOut();
				System.out.println("");
				System.out.println("Could not find initialisation file - " + System.getProperty("user.dir")
						+ File.separator + file);
				return false;
			}
		}
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(initFile);
			// System.out.println("Found initialisation file - " +
			// initFile.getAbsolutePath()
			// + " and created InputStream - " + inputStream);
		} catch (Exception e) {
			SysOutController.resetSysOut();
			e.printStackTrace();
			System.out.println("");
			System.out.println("Could not find initialisation file - " + initFile.getAbsolutePath());
			return false;
		}
		if (inputStream != null) {
			try {
				props.load(inputStream);
				System.out.println("Read initialisation file - " + initFile.getAbsolutePath()
						+ " and loaded properties - " + inputStream);
			} catch (Exception e) {
				SysOutController.resetSysOut();
				e.printStackTrace();
				System.out.println("");
				System.out.println("");
				System.out.println("Error reading property initialisation file " + initialisationFile
						+ " in the classpath " + System.getProperty("java.class.path"));
				return false;
			}
		}
		// else {
		// System.out.println("InputStream = null");
		// System.out.println("Property initialisation file " + initialisationFile + "
		// not found in the classpath "
		// + System.getProperty("java.class.path"));
		// return false;
		// }
		boolean isWindows = Platform.isWindows();
		String extension = isWindows ? ".dll" : ".so";
		String tesseractLib = System.getProperty("tesseractLib");
		String leptLib = System.getProperty("leptLib");
		System.out.println("tesseractLib = " + tesseractLib + "; leptLib = " + leptLib);

		Set<Map.Entry<Object, Object>> entries = props.entrySet();
		boolean externalLibFolderFound = false;
		String externalLibFolder = null;
		for (Map.Entry<Object, Object> entry : entries) {
			System.setProperty(entry.getKey().toString(), entry.getValue().toString());
			if (externalLibFolderKey.equals(entry.getKey().toString())) {
				externalLibFolderFound = true;
				externalLibFolder = entry.getValue().toString();
				externalLibFolder = new File(externalLibFolder).getAbsolutePath();
				// System.setProperty("java.io.tmpdir", entry.getValue().toString());
				// String jnaPath = props.getProperty("jna.library.path");
				// if ((jnaPath == null) || (jnaPath.indexOf("tess") == -1)) {
				// System.setProperty("jna.library.path", entry.getValue().toString() +
				// "/tess4j");
				// }
				// System.setProperty("jna.library.path", "");
				// String libraryPath = props.getProperty("java.library.path");
				// if ((libraryPath == null) || (libraryPath.indexOf("tess") == -1)) {
				// System.setProperty("java.library.path",
				// new StringBuffer().append(libraryPath == null ? "" : libraryPath)
				// .append(";" + entry.getValue().toString() + "/tess4j").toString());
				// }

				// concatenate the existing externallib folder to the PATH (Windows) /
				// LD_LIBRARY_PATH (Unix)
				String libPath = System.getProperty("java.library.path");
				String newPath;
				if ((libPath == null) || libPath.isEmpty()) {
					newPath = externalLibFolder;
				} else {
					newPath = externalLibFolder + File.pathSeparator + libPath;
				}
				System.setProperty("java.library.path", newPath);
			}
			if ("tesseract.datapath".equals(entry.getKey().toString())) {
				System.setProperty("TESSDATA_PREFIX", entry.getValue().toString());
			}
		}
		if (!externalLibFolderFound) {
			// the temp dir is where a folder is made and the native library is copied by
			// java for loading
			System.setProperty("java.io.tmpdir", System.getProperty(inputFolderKey) + "/External Libraries");
			System.setProperty("java.library.path", System.getProperty(inputFolderKey) + "/External Libraries");
		}
		// when Native.loadLibrary or System.loadLibrary is called, it resets the
		// library path.
		// The following is an attempt to subvert that by adding it to the sys_paths
		// variable which is what is called by the loadLibrary() methods to iterate
		// through the library paths, jars, wars, etc to find the native library
		try {
			Field field = ClassLoader.class.getDeclaredField("sys_paths");
			field.setAccessible(true);

			// Create override for sys_paths
			ClassLoader classLoader = ClassLoader.getSystemClassLoader();
			List<String> newSysPaths = new ArrayList<>();
			newSysPaths.add(externalLibFolder);
			newSysPaths.addAll(Arrays.asList((String[]) field.get(classLoader)));
			field.set(classLoader, newSysPaths.toArray(new String[newSysPaths.size()]));
		} catch (Exception e) {

		}

		try {
			// System.out.println("java.library.path = " +
			// System.getProperty("java.library.path"));
			// System.out.println("leptLib = " + leptLib);
			// System.loadLibrary(leptLib);
			String library = externalLibFolder + File.separator + leptLib + extension;
			// System.out.println("Trying to load : " + library);
			System.load(library); // using this as it takes the full path, unlike all the other methods
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Could not load library " + leptLib);
		}
		try {
			// System.out.println("java.library.path = " +
			// System.getProperty("java.library.path"));
			// System.out.println("tesseractLib = " + tesseractLib);
			// System.loadLibrary(tesseractLib);
			String library = externalLibFolder + File.separator + tesseractLib + extension;
			// System.out.println("Trying to load : " + library);
			System.load(library); // using this as it takes the full path, unlike all the other methods
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Could not load library " + tesseractLib);
		}

		// System.out.println("System Properties = " + System.getProperties());
		// solves the problem of "IllegalArgumentException" with Comparator.sort
		// System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
		System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
		// System.out.println("Temp folder = " + System.getProperty("java.io.tmpdir"));
		// System.out.println("Library path = " +
		// System.getProperty("jna.library.path"));
		return true;
	}

	public static boolean getProductSetting(String file, boolean useFallbackInitialisationOption) {

		java.util.Properties props = new java.util.Properties();
		// InputStream inputStream =
		// instance.getClass().getClassLoader().getResourceAsStream(initialisationFile);
		File prodFile = null;
		if ((file != null) && !("".equals(file))) {
			prodFile = new File(file);
		} else {
			if (useFallbackInitialisationOption) {
				prodFile = new File(productSettingsFile);
			} else {
				SysOutController.resetSysOut();
				System.out.println("");
				System.out.println("Could not find product settings file - " + file);
				return false;
			}
		}
		if (!prodFile.exists()) {
			return false;
		}
		if (prodFile.lastModified() == productPropertiesTimestamp) {
			return true;
		}
		CheckProductProperties.reset();
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(prodFile);
		} catch (Exception e) {
			SysOutController.resetSysOut();
			e.printStackTrace();
			System.out.println("");
			System.out.println("");
			System.out.println("Could not find product settings file - " + prodFile.getAbsolutePath());
			return false;
		}
		if (inputStream != null) {
			try {
				props.load(inputStream);
				productPropertiesTimestamp = prodFile.lastModified();
				System.err.println("Reloaded product properties");
			} catch (Exception e) {
				SysOutController.resetSysOut();
				e.printStackTrace();
				System.out.println("");
				System.out.println("");
				System.out.println("Error reading product settings file " + productSettingsFile + " in the classpath "
						+ System.getProperty("java.class.path"));
				return false;
			}
		}
		// else {
		// System.out.println("InputStream = null");
		// System.out.println("Property initialisation file " + initialisationFile + "
		// not found in the classpath "
		// + System.getProperty("java.class.path"));
		// return false;
		// }
		Set<Map.Entry<Object, Object>> entries = props.entrySet();
		boolean fixedProductName = false;
		for (Map.Entry<Object, Object> entry : entries) {
			System.setProperty(entry.getKey().toString(), entry.getValue().toString());
			if ("productname.fixed".equals(entry.getKey().toString())) {
				fixedProductName = "true".equals(entry.getValue().toString());
			}
		}
		boolean productNameGivenForFixedProduct = false;
		boolean sysOut = SysOutController.isWritingToSysout();
		if (!sysOut) {
			SysOutController.resetSysOut();
		}
		System.out.println("----------------------");
		for (Map.Entry<Object, Object> entry : entries) {
			if (!fixedProductName) {
				productNameGivenForFixedProduct = true;
				if ("productname.fixed".equals(entry.getKey().toString())) {
					System.out.println(entry.getKey().toString() + "=" + entry.getValue().toString());
				}
			} else {
				System.out.println(entry.getKey().toString() + "=" + entry.getValue().toString());
				if ("product.name".equals(entry.getKey().toString())) {
					productNameGivenForFixedProduct = true;
					if ("".equals(entry.getValue().toString())) {
						System.out.println("-------------------------------");
						System.out.println(
								"Need a valid product name specified against product.name parameter in product.properties, when productname.fixed=true");

						// Removed this line as returning false leads to exiting the system when
						// initialisation is done at the start. Now, the system will not shut down;
						// instead, the operator can change the parameters in product.properties and
						// continue

						// return false;
					}
				}
			}
		}
		if (!productNameGivenForFixedProduct) {
			System.out.println("-------------------------------");
			System.out.println(
					"Need a valid product name specified against product.name parameter in product.properties, when productname.fixed=true");

			// Removed this line as returning false leads to exiting the system when
			// initialisation is done at the start. Now, the system will not shut down;
			// instead, the operator can change the parameters in product.properties and
			// continue

			// return false;
		}
		if (!sysOut) {
			SysOutController.ignoreSysout();
		}
		ProductPriceData.loadMonths();
		ProductPriceData.loadYears();
		return true;
	}

}
