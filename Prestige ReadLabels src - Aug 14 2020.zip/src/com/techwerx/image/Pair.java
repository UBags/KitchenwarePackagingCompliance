package com.techwerx.image;

import com.techwerx.image.utils.ExclusionList;

public class Pair {

	private Integer a;
	private Integer b;

	public Pair(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public boolean containedIn(ExclusionList<Pair> list) {
		return list.has(this);
	}

	public boolean equals(Pair other) {
		if (this.a == other.a) {
			if (this.b == other.b) {
				return true;
			}
		}
		return false;
	}

}
